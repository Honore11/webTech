package web.webProject.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import web.webProject.Service.OrdersService;
import web.webProject.Service.ClientrService;
import web.webProject.models.Client;
import web.webProject.models.Orders;


import java.util.List;

@Controller
public class OrdersController {
    @Autowired
    ClientrService clientrService;
    @Autowired
    OrdersService ordersService;
    @GetMapping("/showNewOrders")
    public String showOrders(Model model){
        Orders orders= new Orders();
        List<Client>userList= clientrService.listAllUsers();
        model.addAttribute("orders", orders);
        model.addAttribute("userList", userList);

        return "order";
    }
    @PostMapping("/saveOrders")
    public String saveOrder(@ModelAttribute("orders") Orders orders){
        ordersService.saveOrders(orders);
         return "redirect:/orderDashBoard";
    }
    @GetMapping("/orderDashBoard")
    public String orderDashBoard(Model model){
        List<Orders>ListOrders=ordersService.listAllOrders();
        model.addAttribute("ListOrders", ListOrders);
        return "orderDashBoard";
    }
    @GetMapping("/showNeworderForm")
    public String showOrde(Model model){
        Orders orders = new Orders();
        List<Client> clientList = clientrService.listAllUsers();
        model.addAttribute("orders", orders);
        Client client = new Client();
        model.addAttribute("client", client);
        return "orderi";
    }

    @PostMapping("/saveOrder")
    public String saverder(@ModelAttribute("ordrs") Orders orders){
        ordersService.saveOrders(orders);
        return "redirect:/showNeworderForm";
    }

    @GetMapping("/updateOrder/{order_Id}")
    public String updateOrder(@PathVariable(value = "order_Id") Long order_Id, Model model){
        Orders orders=ordersService.findOrderById(order_Id);
        List<Client>usersList= clientrService.listAllUsers();
        model.addAttribute("usersList", usersList);
        model.addAttribute(orders);
        return "updateOrder";
    }
    @GetMapping("/deleteOrder/{order_Id}")
    public String deleteOrder(@PathVariable(value = "order_Id") Long order_Id){
        this.ordersService.deleteOrder(order_Id);
        return "redirect:/orderDashBoard";
    }

}
