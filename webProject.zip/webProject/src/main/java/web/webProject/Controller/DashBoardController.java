package web.webProject.Controller;

import org.springframework.stereotype.Controller;

@Controller
public class DashBoardController {
}
