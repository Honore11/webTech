package web.webProject.models;

public enum Emethod {
    Credit_Card,
    MoMo,
    Cash;
}
