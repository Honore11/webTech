package web.webProject.models;

public enum Edelivery {
    Out_Of_delivered,
    delivered;
}
