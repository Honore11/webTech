package web.webProject.models;

public enum Estatus {
    Pending,
    Complete,
    Failed;
}
